package com.cg.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class accountController {

	@Autowired
	private BankingServices bankingServices;

	@RequestMapping("/openingAccount")
	public ModelAndView registerAccountAction(@ModelAttribute Account account, 
			BindingResult result) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		account = bankingServices.openAccount(account);
		return new ModelAndView("accountOpeningSuccessfulPage","account",account);
	}

	@RequestMapping("/depositAmount")
	public ModelAndView depositAmountAction(@ModelAttribute Account account, BindingResult result) 
			throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException{
		float amount = bankingServices.depositAmount(account.getAccountNo(), account.getTransactions().get(0).getAmount());
		return new ModelAndView("depositToAccount","amount", "Amount has been deposited successfully. Your total account balance is "+amount);
	}
	
	@RequestMapping("/fundsToTransfer")
	public ModelAndView transferAmountAction(@ModelAttribute Account account, @RequestParam("accountTo") int accountTo, BindingResult result) 
			throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		float amount = account.getTransactions().get(0).getAmount();
		bankingServices.fundTransfer(accountTo, account.getAccountNo(), amount, account.getPinNumber());
		return new ModelAndView("fundTransfer","amount", "Amount "+amount+ " has been transferred successfully.");
	}
	
	@RequestMapping("/accountDetails")
	public ModelAndView withdrawAmountAction(@ModelAttribute Account account, BindingResult result) 
			throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		account = bankingServices.getAccountDetails(account.getAccountNo());
		return new ModelAndView("getSpecificAccountDetail","account2", account);
	}

}
