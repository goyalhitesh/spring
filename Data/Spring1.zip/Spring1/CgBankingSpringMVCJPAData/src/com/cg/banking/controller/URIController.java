package com.cg.banking.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;

@Controller
public class URIController {

	Account account;

	@RequestMapping("/")		
	public String getIndexOf() {
		return "IndexPage";
	}

	@RequestMapping("/openAccount")
	public String getOpenAccountPage() {
		return "openAccount";
	}

	@RequestMapping("/depositToAccount")
	public String getDepositToAccountPage() {
		return "depositToAccount";
	}

	@RequestMapping("/withdrawFromAccount")
	public String getWithdrawFromAccountPage() {
		return "withdrawFromAccount";
	}

	@RequestMapping("/fundTransfer")
	public String getFundTransferPage() {
		return "fundTransfer";
	}

	@RequestMapping("/getSpecificAccountDetail")
	public String getSpecificAccountDetailsPage() {
		return "getSpecificAccountDetail";
	}

	@RequestMapping("/allAccountsDetails")
	public String getAllAccountsDetailsPage() {
		return "allAccountsDetails";
	}

	@RequestMapping("/allTransactionDetails")
	public String getAllTransactionDetailsPage() {
		return "allTransactionDetails";
	}

	@RequestMapping("/customerCare")
	public String getCustomerCarePage() {
		return "customerCare";
	}

	@ModelAttribute
	public Account getAccount() {
		account = new Account();
		return account;
	}
}
