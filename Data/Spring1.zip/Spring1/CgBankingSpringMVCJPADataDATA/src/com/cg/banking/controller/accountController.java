package com.cg.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.services.BankingServices;

@Controller
public class accountController {

	@Autowired
	private BankingServices bankingServices;
	
}
