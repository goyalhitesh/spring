package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Address;
import com.cg.movie.beans.Bill;
import com.cg.movie.beans.Customer;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Ticket;
import com.cg.movie.daoservices.BillDaoServices;
import com.cg.movie.daoservices.CustomerDaoServices;
import com.cg.movie.daoservices.MovieDaoServices;
import com.cg.movie.daoservices.TicketDaoServices;
import com.cg.movie.exceptions.BillDetailsNotFoundException;
import com.cg.movie.exceptions.CustomerDetailsNotFoundException;
import com.cg.movie.exceptions.IncorrectPasswordException;
import com.cg.movie.exceptions.InvalidDonationAmountException;
import com.cg.movie.exceptions.InvalidNoOfTicketsException;
import com.cg.movie.exceptions.MovieBookingServicesDownException;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.exceptions.TicketDetailsNotFoundException;

@Component("movieBookingServices")
public class MovieBookingServicesImpl implements MovieBookingServices{
	@Autowired
	private CustomerDaoServices customerDaoServices;
	@Autowired
	private BillDaoServices billDaoServices;
	@Autowired
	private MovieDaoServices movieDaoServices;
	@Autowired
	private TicketDaoServices ticketDaoServices;
	
	@Override
	public int acceptCustomerDetails(String name, String emailId, String dateOfBirth, String password, String phoneNo,
			String addressCity, String addressState, int addressPincode) throws MovieBookingServicesDownException {
		Customer customer = new Customer(name, emailId, dateOfBirth, password, phoneNo, new Address(addressCity, addressState, addressPincode), null);
		customer = customerDaoServices.save(customer);
		return customer.getCustomerId();
	}
	
	@Override
	public Movie addMovie(String movieName, String movieRating, int moviePrice, String movieLanguage, String movieGenre)
			throws MovieBookingServicesDownException {
		Movie movie = new Movie(movieName, movieLanguage, movieGenre, movieRating, moviePrice);
		movie.setTiming1("10:15 AM");
		movie.setTiming2("11:30 AM");
		movie.setTiming3("12:40 PM");
		movie.setTiming4("2:15 PM");
		movie.setTiming5("4:30 PM");
		movie.setTiming6("6:20 PM");
		movie.setTiming7("8:10 PM");
		movie.setTiming8("10:30 PM");
		movie.setTheatre1("Tagore Theatre - Pimpri");
		movie.setTheatre2("ESquare - Xion Mall Theatre");
		movie.setTheatre3("PVR - Phoenix City Mall");
		movie.setTheatre4("Cinepolis - Omaxe City");
		movie.setTheatre5("SRS - Seasons Mall");
		movie.setTheatre6("Omjee Cinemas - Hinjewadi");
		movie.setTheatre7("PVR - Amanora Mall");
		movie.setTheatre7("INOX - Bund Garden");
		movie.setTheatre8("Cinepolis - Aundh");
		movie.setTheatre9("ESquare - Pimple Saudhagar");
		System.out.println(movie);
		movie = movieDaoServices.save(movie);
		System.out.println("hello3");
		return movie;
	}

	@Override
	public int generateBillAmount(int movieCode, int noOfTickets, int donationAmount) throws InvalidNoOfTicketsException, InvalidDonationAmountException, MovieBookingServicesDownException, MovieDetailsNotFoundException {
		Movie movie = movieDaoServices.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("No such movie details are found!!"));
		if(noOfTickets<=0)
			throw new InvalidNoOfTicketsException("Sorry! Number of tickets should be more than 0.");
		if(donationAmount<0)
			throw new InvalidDonationAmountException("Sorry! Donation amount can not be negative.");
		int movieAmount = noOfTickets*movie.getMoviePrice();
		double cgst = movieAmount*2.5/100;
		double sgst = movieAmount*2.5/100;
		double gst = sgst+cgst;
		double convienceFee = 50;
		double totalAmount = movieAmount+gst+convienceFee+donationAmount;
		Bill bill = new Bill(noOfTickets, movie.getMoviePrice(), donationAmount, totalAmount, gst);
		billDaoServices.save(bill);
		return bill.getBillId();
	}

	@Override
	public List<Movie> getAllMovieDetails() throws MovieBookingServicesDownException {
		List<Movie> movies = movieDaoServices.findAll();
		return movies;
	}

	@Override
	public Ticket getTicketDetails(int ticketId)
			throws TicketDetailsNotFoundException, MovieBookingServicesDownException {
		return ticketDaoServices.findById(ticketId).orElseThrow(()->
			new TicketDetailsNotFoundException("Ticket Id is not found! Please check it again."));
	}

	@Override
	public Movie getMovieDetails(String movieName)
			throws MovieDetailsNotFoundException, MovieBookingServicesDownException {
		Movie movie= movieDaoServices.fetchMovieDetails(movieName);
		if(movie==null)
		throw new MovieDetailsNotFoundException("No such movie detail is found! Please enter a valid movie code.");
		return movie;
	}

	@Override
	public Bill getBillDetails(int billId) throws BillDetailsNotFoundException, MovieBookingServicesDownException {
		return billDaoServices.findById(billId).orElseThrow(()->
		new BillDetailsNotFoundException("No such bill details exist! Please enter a valid bill ID."));
	}

	@Override
	public boolean deleteCustomerDetails(int customerId)
			throws CustomerDetailsNotFoundException, MovieBookingServicesDownException {
		Customer customer  = customerDaoServices.findById(customerId).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details are not found! Please enter a valid customer ID."));
		customerDaoServices.delete(customer);
		return true;
	}
	
	@Override
	public boolean deleteMovieDetails(String movieName)
			throws MovieDetailsNotFoundException, MovieBookingServicesDownException {
		Movie movie = movieDaoServices.fetchMovieDetails(movieName);
		if(movie==null) 
			throw new MovieDetailsNotFoundException("No such movie detail is found! Please enter a valid movie code.");
		movieDaoServices.delete(movie);
		return true;
	}

	@Override
	public boolean changePassword(int customerId, String oldPassword, String newPassword)
			throws CustomerDetailsNotFoundException, MovieBookingServicesDownException, IncorrectPasswordException {
		Customer customer  = customerDaoServices.findById(customerId).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details are not found! Please enter a valid customer ID."));
		if(!customer.getPassword().equals(oldPassword))
			throw new IncorrectPasswordException("Incorrect Password! Please enter a valid password.");
		if(oldPassword.equals(newPassword))
			throw new IncorrectPasswordException("Sorry!! Your old password and new password are not equal.");
		if(newPassword.equals(""))
			throw new IncorrectPasswordException("Sorry!! New password field should not be empty.");
		customer.setPassword(newPassword);
		customerDaoServices.save(customer);
		return true;
	}

	@Override
	public int generateTicket(int movieCode, String paymentMethod, int billId, String timing, String theatre)
			throws InvalidNoOfTicketsException, MovieDetailsNotFoundException, BillDetailsNotFoundException,
			MovieBookingServicesDownException {
		Movie movie = movieDaoServices.findById(movieCode).orElseThrow(()->
		new MovieDetailsNotFoundException("No such movie detail is found! Please enter a valid movie code."));
		Bill bill = billDaoServices.findById(billId).orElseThrow(()->
		new BillDetailsNotFoundException("No such bill details are found! Please enter a valid bill ID."));
		Ticket ticket = new Ticket(timing, theatre, paymentMethod, movie, bill,null);
		return ticket.getTicketId();
	}

	@Override
	public Customer getCustomerDetails(int customerId)
			throws CustomerDetailsNotFoundException, MovieBookingServicesDownException {
		Customer customer = customerDaoServices.findById(customerId).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details are not found! Please enter a valid customer ID."));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws MovieBookingServicesDownException {
		List<Customer> customers = customerDaoServices.findAll();
		return customers;
	}
	
}
