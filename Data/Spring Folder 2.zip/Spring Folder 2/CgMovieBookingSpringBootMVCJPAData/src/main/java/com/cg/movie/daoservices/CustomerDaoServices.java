package com.cg.movie.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.movie.beans.Customer;

public interface CustomerDaoServices extends JpaRepository<Customer, Integer> {

}
