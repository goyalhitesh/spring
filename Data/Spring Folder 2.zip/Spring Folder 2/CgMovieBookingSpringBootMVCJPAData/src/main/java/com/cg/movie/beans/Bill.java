package com.cg.movie.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Bill {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="billIdGenerator")
	@SequenceGenerator(name="billIdGenerator", sequenceName="billId_seq", initialValue=5001, allocationSize=0)
	private int billId;
	private int noOfTickets,perMovieTicketPrice,donationAmount;
	private double gst,totalAmount;
	
	public Bill() {
		super();
	}

	public Bill(int noOfTickets, int perMovieTicketPrice, int donationAmount, double totalAmount, double gst) {
		super();
		this.noOfTickets = noOfTickets;
		this.perMovieTicketPrice = perMovieTicketPrice;
		this.donationAmount = donationAmount;
		this.totalAmount = totalAmount;
		this.gst = gst;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

	public int getPerMovieTicketPrice() {
		return perMovieTicketPrice;
	}

	public void setPerMovieTicketPrice(int perMovieTicketPrice) {
		this.perMovieTicketPrice = perMovieTicketPrice;
	}

	public int getDonationAmount() {
		return donationAmount;
	}

	public void setDonationAmount(int donationAmount) {
		this.donationAmount = donationAmount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billId;
		result = prime * result + donationAmount;
		long temp;
		temp = Double.doubleToLongBits(gst);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + noOfTickets;
		result = prime * result + perMovieTicketPrice;
		temp = Double.doubleToLongBits(totalAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		if (billId != other.billId)
			return false;
		if (donationAmount != other.donationAmount)
			return false;
		if (Double.doubleToLongBits(gst) != Double.doubleToLongBits(other.gst))
			return false;
		if (noOfTickets != other.noOfTickets)
			return false;
		if (perMovieTicketPrice != other.perMovieTicketPrice)
			return false;
		if (Double.doubleToLongBits(totalAmount) != Double.doubleToLongBits(other.totalAmount))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", noOfTickets=" + noOfTickets + ", perMovieTicketPrice="
				+ perMovieTicketPrice + ", donationAmount=" + donationAmount + ", totalAmount=" + totalAmount + ", gst="
				+ gst + "]";
	}
}