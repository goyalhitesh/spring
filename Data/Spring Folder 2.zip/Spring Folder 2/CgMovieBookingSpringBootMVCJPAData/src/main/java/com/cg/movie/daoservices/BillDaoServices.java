package com.cg.movie.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.movie.beans.Bill;

public interface BillDaoServices extends JpaRepository<Bill, Integer> {

}
