package com.cg.movie.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import com.cg.movie.beans.Bill;
import com.cg.movie.beans.Customer;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Ticket;
import com.cg.movie.exceptions.BillDetailsNotFoundException;
import com.cg.movie.exceptions.CustomerDetailsNotFoundException;
import com.cg.movie.exceptions.IncorrectPasswordException;
import com.cg.movie.exceptions.InvalidDonationAmountException;
import com.cg.movie.exceptions.InvalidNoOfTicketsException;
import com.cg.movie.exceptions.MovieBookingServicesDownException;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.exceptions.TicketDetailsNotFoundException;
import com.cg.movie.services.MovieBookingServices;
import com.gargoylesoftware.htmlunit.javascript.host.fetch.Request;

@Controller
public class CustomerController {
	@Autowired
	MovieBookingServices movieBookingServices;

	@RequestMapping("/signUp")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws MovieBookingServicesDownException, CustomerDetailsNotFoundException   {
		if(result.hasErrors())
			return new ModelAndView("SignUpPage");
		int customerID = movieBookingServices.acceptCustomerDetails(customer.getName(), customer.getEmailId(), customer.getDateOfBirth(), customer.getPassword(), customer.getPhoneNo(), customer.getAddress().getCity(), customer.getAddress().getState(), customer.getAddress().getPincode());
		customer = movieBookingServices.getCustomerDetails(customerID);
		ModelAndView model = new ModelAndView("SignUpPage", "customer", customer);
		model.addObject("message","Congratulations!! Your Account has successfully regsitered.");
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("/loginCustomer")
	public ModelAndView loginCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result, HttpServletRequest request) throws MovieBookingServicesDownException{
		Customer customer1;
		try {
			if(customer.getCustomerId()==2001 && customer.getPassword().equals("admin123")) {
				ModelAndView model1 = new ModelAndView("adminLoginPage","message","Hey Admin!!");
				return model1;
			}
			customer1 = movieBookingServices.getCustomerDetails(customer.getCustomerId());
			HttpSession session=request.getSession();
			session.setAttribute("customerId", customer.getCustomerId());
			if(!customer.getPassword().equals(customer1.getPassword())) {
				ModelAndView model = new ModelAndView("loginPage","message","Your customerId/Password is incorrect!!");
				return model;
			}
			else {
				ModelAndView model = new ModelAndView("indexPage");
				return model;
			}
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("loginPage","message",e.getMessage());
		}
	}

	@RequestMapping("changePassword")
	public ModelAndView changePasswordAction(@Valid @RequestParam("newPassword") String newPassword, @RequestParam("oldPassword") String oldPassword, @ModelAttribute Customer customer, BindingResult result) {
		try {
			movieBookingServices.changePassword(customer.getCustomerId(), oldPassword, newPassword);
			ModelAndView model = new ModelAndView("changePasswordPage","message","Your password has successfully changed.");
			return model;
		} catch (CustomerDetailsNotFoundException | MovieBookingServicesDownException | IncorrectPasswordException e) {
			return new ModelAndView("changePasswordPage","message",e.getMessage());
		}
	}

	@RequestMapping("addMovie")
	public ModelAndView addMovieAction(@Valid @ModelAttribute Movie movie, BindingResult result) {
		try {
			movie = movieBookingServices.addMovie(movie.getMovieName(), movie.getMovieRating(), movie.getMoviePrice(), movie.getMovieLanguage(), movie.getMovieGenre());
			ModelAndView model = new ModelAndView("addMoviePage","movie",movie);
			model.addObject("message","A new movie "+movie.getMovieName()+ " has successfully added with movie code "+movie.getMovieCode());
			model.addObject("flag","1");
			return model;
		} catch (MovieBookingServicesDownException e) {
			return new ModelAndView("addMoviePage","message",e.getMessage());
		}
	}

	@RequestMapping("allMovieDetails")
	public ModelAndView allMovieDetailsAction(@Valid @ModelAttribute Movie movie, BindingResult result) throws MovieBookingServicesDownException {
		List<Movie> movies = movieBookingServices.getAllMovieDetails();
		movie = movies.get(1);
		ModelAndView model = new ModelAndView("fetchAllMovieDetails","movies",movies);
		model.addObject("movie",movie);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("fetchAllMovieDetails")
	public ModelAndView adminAllMovieDetailsAction(@Valid @ModelAttribute Movie movie, BindingResult result) throws MovieBookingServicesDownException {
		List<Movie> movies = movieBookingServices.getAllMovieDetails();
		movie = movies.get(1);
		ModelAndView model = new ModelAndView("getAllMovieDetails","movies",movies);
		model.addObject("movie",movie);
		model.addObject("flag","1");
		return model;
	}


	@RequestMapping("allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer, BindingResult result) throws MovieBookingServicesDownException {
		List<Customer> customers = movieBookingServices.getAllCustomerDetails();
		ModelAndView model = new ModelAndView("fetchAllCustomerDetails","customers",customers);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("personalDetails")
	public ModelAndView getSpecificCustomerDetailAction(@Valid @ModelAttribute Customer customer, BindingResult result, HttpServletRequest request) throws MovieBookingServicesDownException, CustomerDetailsNotFoundException {
		HttpSession session=request.getSession(false);
		customer = movieBookingServices.getCustomerDetails((int) session.getAttribute("customerId"));
		System.out.println(customer);
		ModelAndView model = new ModelAndView("getSpecificCustomerDetailPage","customer",customer);
		model.addObject("flag","1");
		return model;
	}

	@RequestMapping("bookMovieDetails")
	public ModelAndView bookMovieAction(@Valid @ModelAttribute Movie movie, BindingResult result) throws MovieBookingServicesDownException, CustomerDetailsNotFoundException {
		List<Movie> movies = movieBookingServices.getAllMovieDetails();
		movie = movies.get(1);
		ModelAndView model = new ModelAndView("bookMoviePage","movies", movies);
		model.addObject("movie1", movie);
		return model;
	}

	@RequestMapping("bookAMoive")
	public ModelAndView bookMovieAction(@Valid @RequestParam("movieTheatre") String movieTheatre, @RequestParam("movieTiming") String movieTiming, @RequestParam("noOfTickets") int noOfTickets, @RequestParam("donationAmount") int donationAmount, @ModelAttribute Movie movie, BindingResult result, HttpServletRequest request) throws MovieBookingServicesDownException, CustomerDetailsNotFoundException, MovieDetailsNotFoundException, InvalidNoOfTicketsException, InvalidDonationAmountException, BillDetailsNotFoundException {
		HttpSession session=request.getSession(false);
		Customer customer = movieBookingServices.getCustomerDetails((int) session.getAttribute("customerId"));
		movie = movieBookingServices.getMovieDetails(movie.getMovieName());
		int billId = movieBookingServices.generateBillAmount(movie.getMovieCode(), noOfTickets, donationAmount);
		Bill bill = movieBookingServices.getBillDetails(billId);
		ModelAndView model = new ModelAndView("bookMoviePage","customer",customer);
		model.addObject("movie",movie);
		request.setAttribute("movie", movie);
		request.setAttribute("billid", bill.getBillId());
		model.addObject("bill",bill);
		model.addObject("noOfTickets",noOfTickets);
		model.addObject("noOfTickets",noOfTickets);
		model.addObject("movieTheatre",movieTheatre);
		model.addObject("movieTiming",movieTiming);
		model.addObject("convenienceFee", "50");
		model.addObject("message","Your movie seat is reserved. Proceed to Pay!! ");
		model.addObject("flag","1");
		request.setAttribute("movieTheater", movieTheatre);
		request.setAttribute("movieTiming", movieTiming);
		return model;
	}
	
	@RequestMapping("ticketGeneration")
	public ModelAndView generateTicketAction(@Valid @ModelAttribute Ticket ticket, BindingResult result, HttpServletRequest request) throws InvalidNoOfTicketsException, MovieDetailsNotFoundException, BillDetailsNotFoundException, MovieBookingServicesDownException, TicketDetailsNotFoundException {
		HttpSession session=request.getSession(false);
		int ticketId = movieBookingServices.generateTicket((int) request.getAttribute("movieCode"), ticket.getPaymentMethod(), (int)request.getAttribute("billId"),(String)request.getAttribute("movieTiming"), (String)request.getAttribute("movieTheater"));
		ticket = movieBookingServices.getTicketDetails(ticketId);
		ModelAndView model = new ModelAndView("generateTicketPage","ticket",ticket);
		model.addObject("message1","Your payment of " +request.getAttribute("billAmount")+ " has successfully done!! Thanks for choosing CINEMAS");
		model.addObject("flag","1");
		model.addObject("message2","Your Ticket Id is "+ticketId);
		return model;
	}
	

	
	




}
