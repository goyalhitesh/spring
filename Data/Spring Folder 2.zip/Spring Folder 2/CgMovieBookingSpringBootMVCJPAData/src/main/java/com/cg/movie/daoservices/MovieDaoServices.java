package com.cg.movie.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.movie.beans.Movie;
import com.cg.movie.exceptions.MovieBookingServicesDownException;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;

public interface MovieDaoServices extends JpaRepository<Movie, Integer> {

	@Query("SELECT m FROM Movie m WHERE movieName=?1")
	public Movie fetchMovieDetails(@Param("movieName") String movieName)
			throws MovieDetailsNotFoundException, MovieBookingServicesDownException;
	
	
	
}
