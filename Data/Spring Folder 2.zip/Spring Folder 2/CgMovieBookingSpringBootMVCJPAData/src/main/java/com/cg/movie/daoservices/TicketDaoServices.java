package com.cg.movie.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movie.beans.Ticket;

public interface TicketDaoServices extends JpaRepository<Ticket, Integer> {

}
