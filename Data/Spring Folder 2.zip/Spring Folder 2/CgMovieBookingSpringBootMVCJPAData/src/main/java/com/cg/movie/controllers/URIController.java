package com.cg.movie.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.movie.beans.Customer;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Ticket;

@Controller
public class URIController {
	
	@RequestMapping("/")
	public String getLoginPage() {
		return "loginPage";
	}
	
	@RequestMapping("/frame1")
	public String getFramePage() {
		return "frame1";
	}
	
	@RequestMapping("/signUpPage")
	public String getSignUpPage() {
		return "SignUpPage";
	}
	
	@RequestMapping("/homePage")
	public String getHomePage() {
		return "loginPage";
	}
	
	@RequestMapping("/indexPage")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/adminIndexPage")
	public String getAdminIndexPage() {
		return "adminLoginPage";
	}
	
	@RequestMapping("/passwordChange")
	public String getChangePasswordPage() {
		return "changePasswordPage";
	}
	
	@RequestMapping("/addMovieDetails")
	public String getaddMoviePage() {
		return "addMoviePage";
	}
	
	@RequestMapping("/paymentPage")
	public String getPaymentPage() {
		return "generateTicketPage";
	}
	
	
	
	
	
	
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	
	@ModelAttribute
	public Movie getMovie() {
		return new Movie();
	}
	
	@ModelAttribute
	public Ticket getTicket() {
		return new Ticket();
	}
}