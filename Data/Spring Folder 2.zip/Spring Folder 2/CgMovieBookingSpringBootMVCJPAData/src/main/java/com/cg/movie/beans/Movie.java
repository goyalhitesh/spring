package com.cg.movie.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="movieCodeGenerator")
	@SequenceGenerator(name="movieCodeGenerator", sequenceName="movieCode_seq", initialValue=111, allocationSize=0)
	private int movieCode;
	@NotEmpty
	private String movieName;
	@NotEmpty
	private String movieLanguage;
	@NotEmpty
	private String movieGenre;
	@NotEmpty
	private String movieRating;
	private int moviePrice;
	private String timing1,timing2,timing3,timing4,timing5,timing6,timing7,timing8;
	private String theatre1,theatre2,theatre3,theatre4,theatre5,theatre6,theatre7,theatre8,theatre9;
	
	public Movie() {
		super();
	}

	public Movie(String movieName, String movieLanguage, String movieGenre, String movieRating, int moviePrice) {
		super();
		this.movieName = movieName;
		this.movieLanguage = movieLanguage;
		this.movieGenre = movieGenre;
		this.movieRating = movieRating;
		this.moviePrice = moviePrice;
	}

	public int getMovieCode() {
		return movieCode;
	}

	public void setMovieCode(int movieCode) {
		this.movieCode = movieCode;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getMovieLanguage() {
		return movieLanguage;
	}

	public void setMovieLanguage(String movieLanguage) {
		this.movieLanguage = movieLanguage;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	public String getMovieRating() {
		return movieRating;
	}

	public void setMovieRating(String movieRating) {
		this.movieRating = movieRating;
	}

	public int getMoviePrice() {
		return moviePrice;
	}

	public void setMoviePrice(int moviePrice) {
		this.moviePrice = moviePrice;
	}

	public String getTiming1() {
		return timing1;
	}

	public void setTiming1(String timing1) {
		this.timing1 = timing1;
	}

	public String getTiming2() {
		return timing2;
	}

	public void setTiming2(String timing2) {
		this.timing2 = timing2;
	}

	public String getTiming3() {
		return timing3;
	}

	public void setTiming3(String timing3) {
		this.timing3 = timing3;
	}

	public String getTiming4() {
		return timing4;
	}

	public void setTiming4(String timing4) {
		this.timing4 = timing4;
	}

	public String getTiming5() {
		return timing5;
	}

	public void setTiming5(String timing5) {
		this.timing5 = timing5;
	}

	public String getTiming6() {
		return timing6;
	}

	public void setTiming6(String timing6) {
		this.timing6 = timing6;
	}

	public String getTiming7() {
		return timing7;
	}

	public void setTiming7(String timing7) {
		this.timing7 = timing7;
	}

	public String getTiming8() {
		return timing8;
	}

	public void setTiming8(String timing8) {
		this.timing8 = timing8;
	}

	public String getTheatre1() {
		return theatre1;
	}

	public void setTheatre1(String theatre1) {
		this.theatre1 = theatre1;
	}

	public String getTheatre2() {
		return theatre2;
	}

	public void setTheatre2(String theatre2) {
		this.theatre2 = theatre2;
	}

	public String getTheatre3() {
		return theatre3;
	}

	public void setTheatre3(String theatre3) {
		this.theatre3 = theatre3;
	}

	public String getTheatre4() {
		return theatre4;
	}

	public void setTheatre4(String theatre4) {
		this.theatre4 = theatre4;
	}

	public String getTheatre5() {
		return theatre5;
	}

	public void setTheatre5(String theatre5) {
		this.theatre5 = theatre5;
	}

	public String getTheatre6() {
		return theatre6;
	}

	public void setTheatre6(String theatre6) {
		this.theatre6 = theatre6;
	}

	public String getTheatre7() {
		return theatre7;
	}

	public void setTheatre7(String theatre7) {
		this.theatre7 = theatre7;
	}

	public String getTheatre8() {
		return theatre8;
	}

	public void setTheatre8(String theatre8) {
		this.theatre8 = theatre8;
	}

	public String getTheatre9() {
		return theatre9;
	}

	public void setTheatre9(String theatre9) {
		this.theatre9 = theatre9;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + movieCode;
		result = prime * result + ((movieGenre == null) ? 0 : movieGenre.hashCode());
		result = prime * result + ((movieLanguage == null) ? 0 : movieLanguage.hashCode());
		result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
		result = prime * result + moviePrice;
		result = prime * result + ((movieRating == null) ? 0 : movieRating.hashCode());
		result = prime * result + ((theatre1 == null) ? 0 : theatre1.hashCode());
		result = prime * result + ((theatre2 == null) ? 0 : theatre2.hashCode());
		result = prime * result + ((theatre3 == null) ? 0 : theatre3.hashCode());
		result = prime * result + ((theatre4 == null) ? 0 : theatre4.hashCode());
		result = prime * result + ((theatre5 == null) ? 0 : theatre5.hashCode());
		result = prime * result + ((theatre6 == null) ? 0 : theatre6.hashCode());
		result = prime * result + ((theatre7 == null) ? 0 : theatre7.hashCode());
		result = prime * result + ((theatre8 == null) ? 0 : theatre8.hashCode());
		result = prime * result + ((theatre9 == null) ? 0 : theatre9.hashCode());
		result = prime * result + ((timing1 == null) ? 0 : timing1.hashCode());
		result = prime * result + ((timing2 == null) ? 0 : timing2.hashCode());
		result = prime * result + ((timing3 == null) ? 0 : timing3.hashCode());
		result = prime * result + ((timing4 == null) ? 0 : timing4.hashCode());
		result = prime * result + ((timing5 == null) ? 0 : timing5.hashCode());
		result = prime * result + ((timing6 == null) ? 0 : timing6.hashCode());
		result = prime * result + ((timing7 == null) ? 0 : timing7.hashCode());
		result = prime * result + ((timing8 == null) ? 0 : timing8.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (movieCode != other.movieCode)
			return false;
		if (movieGenre == null) {
			if (other.movieGenre != null)
				return false;
		} else if (!movieGenre.equals(other.movieGenre))
			return false;
		if (movieLanguage == null) {
			if (other.movieLanguage != null)
				return false;
		} else if (!movieLanguage.equals(other.movieLanguage))
			return false;
		if (movieName == null) {
			if (other.movieName != null)
				return false;
		} else if (!movieName.equals(other.movieName))
			return false;
		if (moviePrice != other.moviePrice)
			return false;
		if (movieRating == null) {
			if (other.movieRating != null)
				return false;
		} else if (!movieRating.equals(other.movieRating))
			return false;
		if (theatre1 == null) {
			if (other.theatre1 != null)
				return false;
		} else if (!theatre1.equals(other.theatre1))
			return false;
		if (theatre2 == null) {
			if (other.theatre2 != null)
				return false;
		} else if (!theatre2.equals(other.theatre2))
			return false;
		if (theatre3 == null) {
			if (other.theatre3 != null)
				return false;
		} else if (!theatre3.equals(other.theatre3))
			return false;
		if (theatre4 == null) {
			if (other.theatre4 != null)
				return false;
		} else if (!theatre4.equals(other.theatre4))
			return false;
		if (theatre5 == null) {
			if (other.theatre5 != null)
				return false;
		} else if (!theatre5.equals(other.theatre5))
			return false;
		if (theatre6 == null) {
			if (other.theatre6 != null)
				return false;
		} else if (!theatre6.equals(other.theatre6))
			return false;
		if (theatre7 == null) {
			if (other.theatre7 != null)
				return false;
		} else if (!theatre7.equals(other.theatre7))
			return false;
		if (theatre8 == null) {
			if (other.theatre8 != null)
				return false;
		} else if (!theatre8.equals(other.theatre8))
			return false;
		if (theatre9 == null) {
			if (other.theatre9 != null)
				return false;
		} else if (!theatre9.equals(other.theatre9))
			return false;
		if (timing1 == null) {
			if (other.timing1 != null)
				return false;
		} else if (!timing1.equals(other.timing1))
			return false;
		if (timing2 == null) {
			if (other.timing2 != null)
				return false;
		} else if (!timing2.equals(other.timing2))
			return false;
		if (timing3 == null) {
			if (other.timing3 != null)
				return false;
		} else if (!timing3.equals(other.timing3))
			return false;
		if (timing4 == null) {
			if (other.timing4 != null)
				return false;
		} else if (!timing4.equals(other.timing4))
			return false;
		if (timing5 == null) {
			if (other.timing5 != null)
				return false;
		} else if (!timing5.equals(other.timing5))
			return false;
		if (timing6 == null) {
			if (other.timing6 != null)
				return false;
		} else if (!timing6.equals(other.timing6))
			return false;
		if (timing7 == null) {
			if (other.timing7 != null)
				return false;
		} else if (!timing7.equals(other.timing7))
			return false;
		if (timing8 == null) {
			if (other.timing8 != null)
				return false;
		} else if (!timing8.equals(other.timing8))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Movie [movieCode=" + movieCode + ", movieName=" + movieName + ", movieLanguage=" + movieLanguage
				+ ", movieGenre=" + movieGenre + ", movieRating=" + movieRating + ", moviePrice=" + moviePrice
				+ ", timing1=" + timing1 + ", timing2=" + timing2 + ", timing3=" + timing3 + ", timing4=" + timing4
				+ ", timing5=" + timing5 + ", timing6=" + timing6 + ", timing7=" + timing7 + ", timing8=" + timing8
				+ ", theatre1=" + theatre1 + ", theatre2=" + theatre2 + ", theatre3=" + theatre3 + ", theatre4="
				+ theatre4 + ", theatre5=" + theatre5 + ", theatre6=" + theatre6 + ", theatre7=" + theatre7
				+ ", theatre8=" + theatre8 + ", theatre9=" + theatre9 + "]";
	}
}