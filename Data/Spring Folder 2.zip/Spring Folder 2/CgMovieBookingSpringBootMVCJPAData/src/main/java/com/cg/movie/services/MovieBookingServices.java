package com.cg.movie.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.movie.beans.Address;
import com.cg.movie.beans.Bill;
import com.cg.movie.beans.Customer;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Ticket;
import com.cg.movie.exceptions.BillDetailsNotFoundException;
import com.cg.movie.exceptions.CustomerDetailsNotFoundException;
import com.cg.movie.exceptions.IncorrectPasswordException;
import com.cg.movie.exceptions.InvalidDonationAmountException;
import com.cg.movie.exceptions.InvalidNoOfTicketsException;
import com.cg.movie.exceptions.MovieBookingServicesDownException;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.exceptions.TicketDetailsNotFoundException;

public interface MovieBookingServices {
	
	int acceptCustomerDetails(String name, String emailId, String dateOfBirth,
			 String password, String phoneNo, String addressCity, String addressState, int addressPincode) throws MovieBookingServicesDownException;
	
	Movie addMovie(String movieName, String movieRating,  int moviePrice, String movieLanguage, String movieGenre) throws MovieBookingServicesDownException;
	
	int generateBillAmount(int movieCode, int noOfTickets, int donationAmount) throws InvalidNoOfTicketsException, InvalidDonationAmountException, MovieBookingServicesDownException, MovieDetailsNotFoundException;
	
	List<Movie> getAllMovieDetails() throws MovieBookingServicesDownException;
	
	Ticket getTicketDetails(int ticketId) throws TicketDetailsNotFoundException, MovieBookingServicesDownException;
	
	Movie getMovieDetails(String movieName) throws MovieDetailsNotFoundException, MovieBookingServicesDownException;
	
	Bill getBillDetails(int billId) throws BillDetailsNotFoundException, MovieBookingServicesDownException;
	
	boolean deleteCustomerDetails(int customerId) throws CustomerDetailsNotFoundException, MovieBookingServicesDownException;
	
	boolean deleteMovieDetails(String movieName) throws MovieDetailsNotFoundException, MovieBookingServicesDownException;
	
	boolean changePassword(int customerId, String oldPassword, String newPassword) throws CustomerDetailsNotFoundException, MovieBookingServicesDownException, IncorrectPasswordException;
	
	int generateTicket(int movieCode,String paymentMethod, int billId, String timing, String theatre) throws InvalidNoOfTicketsException, MovieDetailsNotFoundException, BillDetailsNotFoundException, MovieBookingServicesDownException;
	
	Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException, MovieBookingServicesDownException;
	
	List<Customer> getAllCustomerDetails() throws MovieBookingServicesDownException;

}

