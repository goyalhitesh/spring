package com.cg.github.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.springframework.core.io.PathResource;

public class RegistrationPage {
	@FindBy(name="firstName")
	private WebElement firstName;
	
	@FindBy(name="lastName")
	private WebElement lastName;
	
	@FindBy(name="department")
	private WebElement department;
	
	@FindBy(name="emailId")
	private WebElement emailId;
	
	@FindBy(name="designation")
	private WebElement designation;
	
	@FindBy(name="bankDetail.bankName")
	private WebElement bankName;
	
	@FindBy(name="salary.epf")
	private WebElement epf;
	
	@FindBy(name="salary.companyPf")
	private WebElement companyPf;
	
	@FindBy(name="submit")
	private WebElement submit;
	
	/*@FindBy(how=How.XPATH,xpath="//*[@id=\"js-flash-container\"]/div/div")
	private WebElement actualErrorMessage;*/

	public RegistrationPage() {}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getDepartment() {
		return department.getAttribute("value");
	}

	public void setDepartment(String department) {
		this.department.sendKeys(department);;
	}

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);;
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public String getBankName() {
		return bankName.getAttribute("value");
	}

	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);;
	}

	public String getEpf() {
		return epf.getAttribute("value");
	}

	public void setEpf(String epf) {
		this.epf.clear();
		this.epf.sendKeys(epf);
	}

	public String getCompanyPf() {
		this.companyPf.clear();
		return companyPf.getAttribute("value");
	}

	public void setCompanyPf(String companyPf) {
		this.companyPf.sendKeys(companyPf);
	}

	public void clickSubmit() {
		submit.click();
	}
}
	
	

	