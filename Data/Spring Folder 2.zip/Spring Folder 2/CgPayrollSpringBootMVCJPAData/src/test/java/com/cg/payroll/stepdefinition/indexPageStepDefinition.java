package com.cg.payroll.stepdefinition;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.github.pagebeans.indexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class indexPageStepDefinition {

	private WebDriver driver;
	private indexPage indexpage;
	
	@Given("^User is on Payroll IndexPage$")
	public void user_is_on_Payroll_IndexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/");
		indexpage = PageFactory.initElements(driver, indexPage.class);
	}

	@When("^User clicks on Registration$")
	public void user_clicks_on_Registration() throws Throwable {
		indexpage.clickRegistration();
	}

	@Then("^He must be sent to RegistrationPage$")
	public void he_must_be_sent_to_RegistrationPage() throws Throwable {
		String expectedTitle = "Registration";
		assertEquals(expectedTitle,driver.getTitle());
		driver.close();
	}
}
