package com.cg.payroll.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.RegistrationPage;
import com.cg.github.pagebeans.indexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class registrationPageStepDefinition {
	
	private WebDriver driver;
	private RegistrationPage registrationPage;
	
	@Given("^User is on Payroll RegistrationPage$")
	public void user_is_on_Payroll_RegistrationPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/registration");
		registrationPage = PageFactory.initElements(driver, RegistrationPage.class);
	}

	@When("^User enters all details correctly$")
	public void user_enters_all_details_correctly() throws Throwable {
		registrationPage.setFirstName("Hitesh");
		registrationPage.setLastName("Goyal");
		registrationPage.setDepartment("ADM");
		registrationPage.setEmailId("hitesh@gmail.com");
		registrationPage.setDesignation("Senior Analyst");
		registrationPage.setBankName("HDFC");
		registrationPage.setEpf("1248");
		registrationPage.setCompanyPf("1248");
		registrationPage.clickSubmit();
	}

	@Then("^He must be redirected to RegistrationSuccessfullyPage$")
	public void he_must_be_redirected_to_RegistrationSuccessfullyPage() throws Throwable {
		String expectedTitle = "RegisteredSuccessfully";
		assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}

	@When("^User enters any detail incorrectly$")
	public void user_enters_any_detail_incorrectly() throws Throwable {

	}

	@Then("^He must be redirected to RegistrationPage again$")
	public void he_must_be_redirected_to_RegistrationPage_again() throws Throwable {

	}
}
