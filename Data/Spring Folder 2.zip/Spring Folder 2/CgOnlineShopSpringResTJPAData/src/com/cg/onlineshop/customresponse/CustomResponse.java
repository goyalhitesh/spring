package com.cg.onlineshop.customresponse;

public class CustomResponse {
	private int statusCode;
	private String reponseMessage;
	public CustomResponse() {
		super();
	}
	public CustomResponse(int statusCode, String reponseMessage) {
		super();
		this.statusCode = statusCode;
		this.reponseMessage = reponseMessage;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getReponseMessage() {
		return reponseMessage;
	}
	public void setReponseMessage(String reponseMessage) {
		this.reponseMessage = reponseMessage;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((reponseMessage == null) ? 0 : reponseMessage.hashCode());
		result = prime * result + statusCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomResponse other = (CustomResponse) obj;
		if (reponseMessage == null) {
			if (other.reponseMessage != null)
				return false;
		} else if (!reponseMessage.equals(other.reponseMessage))
			return false;
		if (statusCode != other.statusCode)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CustomResponse [statusCode=" + statusCode + ", reponseMessage=" + reponseMessage + "]";
	}
}