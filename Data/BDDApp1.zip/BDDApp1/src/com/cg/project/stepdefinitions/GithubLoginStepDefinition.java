package com.cg.project.stepdefinitions;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubLoginStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	@Given("^User is on GitHub HomePage$")
	public void user_is_on_GitHub_HomePage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		
		loginPage = PageFactory.initElements(driver, LoginPage.class);
	}
	
	@When("^User enters his login credentials incorrectly$")
	public void user_enters_his_login_credentials_incorrectly() throws Throwable {
		loginPage.setUsername("sammrgoel@gmail.com");
		loginPage.setPassword("hhgg11");
		loginPage.clickSignIn();
	}

	@Then("^Displays an error message to user$")
	public void displays_an_error_message_to_user() throws Throwable {
		/*System.out.println(loginPage.getActualErrorMessage());*/
		String expectedTitle = "Incorrect username or password.";
		assertEquals(expectedTitle, loginPage.getActualErrorMessage());
		driver.close();
	}

	@When("^User enters his login credentials correctly$")
	public void user_enters_his_login_credentials_correctly() throws Throwable {
		/*By by = By.name("login");
		WebElement searchText = driver.findElement(by);
		searchText.sendKeys("sammrgoel@gmail.com");
		By by1 = By.name("password");
		WebElement searchText1 = driver.findElement(by1);
		searchText1.sendKeys("hhgg11##");
		searchText.submit();*/
		
		loginPage.setUsername("sammrgoel@gmail.com");
		loginPage.setPassword("hhgg11##");
		loginPage.clickSignIn();
	}

	@Then("^User is redirected to his account$")
	public void user_is_redirected_to_his_account() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "GitHub";
		assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
