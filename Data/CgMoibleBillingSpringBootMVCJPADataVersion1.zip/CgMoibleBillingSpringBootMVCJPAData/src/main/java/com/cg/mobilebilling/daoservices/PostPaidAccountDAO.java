package com.cg.mobilebilling.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

public interface PostPaidAccountDAO extends JpaRepository<PostpaidAccount, Long> {
	@Query("SELECT p FROM PostpaidAccount p WHERE p.customer.customerID = :customerID")
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(@Param("customerID") int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException;
	
	@Transactional
	@Modifying
	@Query("DELETE FROM PostpaidAccount P WHERE P.mobileNo=?1")
	public void deletePostpaidAccount(@Param("mobileNo") long mobileNo)
	throws PostpaidAccountNotFoundException, BillingServicesDownException;
}
