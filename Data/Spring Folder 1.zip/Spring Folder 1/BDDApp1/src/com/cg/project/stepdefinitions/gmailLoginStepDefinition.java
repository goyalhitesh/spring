package com.cg.project.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class gmailLoginStepDefinition {
		@Given("^User is on Gmail SignInPage$")
		public void user_is_on_Gmail_SignInPage() throws Throwable {

		}

		@When("^User enter his login credentials correct$")
		public void user_enter_his_login_credentials_correct() throws Throwable {

		}

		@Then("^He must be redirected to his gmail account$")
		public void he_must_be_redirected_to_his_gmail_account() throws Throwable {

		}
}
