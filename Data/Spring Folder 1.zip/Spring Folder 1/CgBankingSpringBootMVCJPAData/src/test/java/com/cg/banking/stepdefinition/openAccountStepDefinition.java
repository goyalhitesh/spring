package com.cg.banking.stepdefinition;

public class openAccountStepDefinition {

}
