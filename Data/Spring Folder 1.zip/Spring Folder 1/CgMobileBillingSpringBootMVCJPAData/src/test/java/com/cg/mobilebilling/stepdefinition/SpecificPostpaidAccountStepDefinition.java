package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SpecificPostpaidAccountStepDefinition {

	@Given("^User is on getPostPaidAccountDetailsPage Page$")
	public void user_is_on_getPostPaidAccountDetailsPage_Page() throws Throwable {

	}

	@When("^User enter his correct credentials and click on get postpaid account details button$")
	public void user_enter_his_correct_credentials_and_click_on_get_postpaid_account_details_button() throws Throwable {

	}

	@Then("^User is redirected to getPostPaidAccountDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getPostPaidAccountDetailsPage_page_and_details_gets_displayed() throws Throwable {

	}
}
