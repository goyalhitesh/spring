/*package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.MonthlyBillDetailPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateMonthlyBillStepDefinition {
	
	private WebDriver driver;
	private MonthlyBillDetailPage monthlyBillDetail;

	@Given("^User is on generateMonthlyMobileBillPage Page$")
	public void user_is_on_generateMonthlyMobileBillPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:3333/generateMonthlyMobileBill");
		monthlyBillDetail = PageFactory.initElements(driver, MonthlyBillDetailPage.class);
	}
	
	@When("^User enter his bill details correctly and click on submit button$")
	public void user_enter_his_bill_details_correctly_and_click_on_submit_button() throws Throwable {
		monthlyBillDetail.setCustomerID("20023");
		monthlyBillDetail.setMobileNo("987654343");
		monthlyBillDetail.setBillMonth("August");
		monthlyBillDetail.setNoOfLocalSMS("1545");
		monthlyBillDetail.setNoOfStdSMS("581");
		monthlyBillDetail.setNoOfLocalCalls("767");
		monthlyBillDetail.setNoOfStdCalls("185");
		monthlyBillDetail.setInternetDataUsageUnits("6");
		monthlyBillDetail.generateBill();
	}

	@Then("^User is redirected to generateMonthlyMobileBillPage page and message gets displayed$")
	public void user_is_redirected_to_generateMonthlyMobileBillPage_page_and_message_gets_displayed() throws Throwable {
		String expectedTitle="Generate Monthly Bill";
		assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}
	
	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
		monthlyBillDetail.homePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String expectedTitle1 = "WebApp1";
		assertEquals(expectedTitle1, driver.getTitle());
//		driver.close();
	}
}
*/