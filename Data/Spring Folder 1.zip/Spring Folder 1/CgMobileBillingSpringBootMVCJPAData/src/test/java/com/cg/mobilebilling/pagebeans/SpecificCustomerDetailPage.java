package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SpecificCustomerDetailPage {
	@FindBy(name="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/table/tbody/tr[2]/td/input")
	private WebElement submit;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/table/tbody/tr/td/input")
	private WebElement homepage;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[1]")
	private WebElement actualFirstName;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[2]")
	private WebElement actualLastName;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[3]")
	private WebElement actualEmail;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[4]")
	private WebElement actualDateOfBirth;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/table/tbody/tr/td")
	private WebElement actualErrorMessage;
	
	public SpecificCustomerDetailPage() {
		super();
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}
	
	public String getExpectedFirstName() {
		return actualFirstName.getText();
	}

	public String getExpectedLastName() {
		return actualLastName.getText();
	}

	public String getExpectedEmail() {
		return actualEmail.getText();
	}

	public String getExpectedDateOfBirth() {
		return actualDateOfBirth.getText();
	}
	
	public String getActualErrorMessage() {
		return actualErrorMessage.getText();
	}

	public void getDetails() {
		submit.click();
	}
	
	public void homePage() {
		homepage.click();
	}
}
