package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MobilePlanDetailStepDefinition {

	@Then("^User is redirected to getPlanAllDetails page and get details of all plans$")
	public void user_is_redirected_to_getPlanAllDetails_page_and_get_details_of_all_plans() throws Throwable {

	}

	@Given("^User is on getPlanAllDetailsPage Page$")
	public void user_is_on_getPlanAllDetailsPage_Page() throws Throwable {

	}
}
