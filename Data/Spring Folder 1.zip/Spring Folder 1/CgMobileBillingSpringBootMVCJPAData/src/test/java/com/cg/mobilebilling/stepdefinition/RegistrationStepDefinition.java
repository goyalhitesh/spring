/*package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.PostpaidAccountPage;
import com.cg.mobilebilling.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	
	private WebDriver driver;
	private RegistrationPage registrationPage;

	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:3333/registration");
		registrationPage = PageFactory.initElements(driver, RegistrationPage.class);
	}
	
	@When("^User enter his correct credentials and click on submit button$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button() throws Throwable {
		registrationPage.setFirstName("Hitakshi");
		registrationPage.setLastName("Bansal");
		registrationPage.setEmailID("hitakshi@gmail.com");
		registrationPage.setDateOfBirth("04/08/1997");
		registrationPage.setCity("Nabha");
		registrationPage.setState("Punjab");
		registrationPage.setPinCode("147201");
		registrationPage.RegisterCustomer();
	}

	@Then("^User is redirected to registration page and message gets displayed$")
	public void user_is_redirected_to_registration_page_and_message_gets_displayed() throws Throwable {
		String expectedTitle = "RegisteredSuccessfully";
		assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}
	
	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
		registrationPage.homePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String expectedTitle1 = "WebApp1";
		assertEquals(expectedTitle1, driver.getTitle());
//		driver.close();
	}
	
	@When("^User enter his incorrect credentials and click on submit button$")
	public void user_enter_his_incorrect_credentials_and_click_on_submit_button() throws Throwable {
		registrationPage.setFirstName("Hitakshi");
		registrationPage.setLastName("");
		registrationPage.setEmailID("hitakshi@gmail.com");
		registrationPage.setDateOfBirth("");
		registrationPage.setCity("Nabha");
		registrationPage.setState("");
		registrationPage.setPinCode("147201");
		registrationPage.RegisterCustomer();
	}

	@Then("^Display all the error messages$")
	public void display_all_the_error_messages() throws Throwable {
		String expectedError1 = "Enter Last Name";
		assertEquals(expectedError1, registrationPage.getLastNameError());
		String expectedError2 = "Enter Date of Birth";
		assertEquals(expectedError2, registrationPage.getDateOfBirthError());
		String expectedError3 = "Enter State";
		assertEquals(expectedError3, registrationPage.getStateError());
		driver.close();
	}
}
*/