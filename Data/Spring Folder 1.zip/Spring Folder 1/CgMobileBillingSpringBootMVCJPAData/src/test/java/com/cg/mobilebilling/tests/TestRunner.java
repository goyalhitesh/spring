package com.cg.mobilebilling.tests;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"features"},
		glue= {"com.cg.mobilebilling.stepdefinition"},
		tags = {"~@Ignore"}
		)

public class TestRunner {

}