/*package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilebilling.pagebeans.SpecificCustomerDetailPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SpecificCustomerDetailStepDefinition {
	
	private WebDriver driver;
	private SpecificCustomerDetailPage specificCustomer;
	

	@Given("^User is on getCustomerDetailsPage Page$")
	public void user_is_on_getCustomerDetailsPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:3333/customerDetails");
		specificCustomer = PageFactory.initElements(driver, SpecificCustomerDetailPage.class);
	}
	
	@When("^User enter his customer ID correctly$")
	public void user_enter_his_customer_ID_correctly() throws Throwable {
	    specificCustomer.setCustomerID("20023");
	    specificCustomer.getDetails();
	}

	@Then("^User is redirected to getCustomerDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerDetailsPage_page_and_details_gets_displayed() throws Throwable {
		String expectedFirstName="Hitakshi";
		assertEquals(specificCustomer.getExpectedFirstName(), expectedFirstName);
		String expectedLastName="Bansal";
		assertEquals(expectedLastName, specificCustomer.getExpectedLastName());
		String expectedEmail = "hitakshi@gmail.com";
		assertEquals(expectedEmail, specificCustomer.getExpectedEmail());
		String expectedDateOfBirth = "04/08/1997";
		assertEquals(expectedDateOfBirth, specificCustomer.getExpectedDateOfBirth());
		//driver.close();
	}
	
	@When("^User enter his customer ID incorrectly$")
	public void user_enter_his_customer_ID_incorrectly() throws Throwable {
		specificCustomer.setCustomerID("20029");
	    specificCustomer.getDetails();
	}

	@Then("^Display Error on the same page$")
	public void display_Error_on_the_same_page() throws Throwable {
	    String expectedErrorMessage = "No Customer Details Found!";
	    assertEquals(expectedErrorMessage, specificCustomer.getActualErrorMessage());
	  //driver.close();
	}

	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
	    specificCustomer.homePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String expectedTitle1 = "WebApp1";
		assertEquals(expectedTitle1, driver.getTitle());
		//driver.close();
	}
}
*/