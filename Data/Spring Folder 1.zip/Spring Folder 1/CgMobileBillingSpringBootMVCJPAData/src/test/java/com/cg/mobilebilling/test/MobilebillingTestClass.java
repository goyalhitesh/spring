package com.cg.mobilebilling.test;

import org.easymock.EasyMockRunner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDetailsDAO;
import com.cg.mobilebilling.daoservices.PostPaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;
@RunWith(EasyMockRunner.class)
public class MobilebillingTestClass {
	@MockBean
	BillingDAOServices billingDAOServicesMock;
	@MockBean
	CustomerDAO customerDAOServicesMock;
	@MockBean
	PlanDetailsDAO planDAOServicesMock;
	@MockBean
	PostPaidAccountDAO postpaidDAOServicesMock;
	BillingServices billingServices=new BillingServicesImpl();

	private static Customer cust1,cust2;
	private static Plan plan1,plan2;
	private static PostpaidAccount account1,account2;

	@BeforeClass
	public static void setUPTestEnv(){

	}

	@Before
	public void setUPMockDataForTest(){
			cust1=new Customer("Hitesh", "Goyal", "hitesh@gmail.com", "01/12/1996", new Address(147001, "Patiala", "Punjab"), null);
			cust2=new Customer("Rahul", "Singla", "rahul@gmail.com", "26/11/1995", new Address(160071, "Mohali", "Punjab"),null);
			plan1=new Plan(101,299,1000,300,500,450,1000,0.70f,0.40f,0.25f,0.67f,0.30f,"Punjab", "Bronze",null);
			plan2=new Plan(102,399,1500,350,800,700,1200,0.70f,0.40f,0.25f,0.67f,0.30f,"Punjab", "Gold",null);
			account1=new PostpaidAccount(987654322, plan1, null, cust1);
			account2=new PostpaidAccount(987654323, plan2, null,cust2);
		}
		@Test
		public void accepCustomerDetailsTest() throws BillingServicesDownException {
			
		}

	@After
	public void tearDownMockDataForTest(){
		System.out.println("tearDownMockDataForTest()");
	}

	@AfterClass
	public static void tearDownTestEnv(){

	}
}
