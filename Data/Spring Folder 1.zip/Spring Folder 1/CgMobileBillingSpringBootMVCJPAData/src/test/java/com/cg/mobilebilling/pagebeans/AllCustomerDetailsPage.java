package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AllCustomerDetailsPage {

	@FindBy(how=How.XPATH, xpath="//*[@id=\"customer\"]/table/tbody/tr/td/input")
	private WebElement getAllCustomerDetails;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div/div/form/table/tbody/tr/td/input")
	private WebElement homepage;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[3]")
	private WebElement actualEmail1;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div[2]/form/table/tbody/tr[3]/td[3]")
	private WebElement actualEmail2;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div[2]/form/table/tbody/tr[4]/td[3]")
	private WebElement actualEmail3;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div[2]/form/table/tbody/tr[5]/td[3]")
	private WebElement actualEmail4;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div[2]/form/table/tbody/tr[6]/td[3]")
	private WebElement actualEmail5;

	public AllCustomerDetailsPage() {
		super();
	}

	public String getActualEmail1() {
		return actualEmail1.getText();
	}
	
	public String getActualEmail2() {
		return actualEmail2.getText();
	}

	public String getActualEmail3() {
		return actualEmail3.getText();
	}
	
	public String getActualEmail4() {
		return actualEmail4.getText();
	}

	public String getActualEmail5() {
		return actualEmail5.getText();
	}
	
	public void homePage() {
		homepage.click();
	}
	
	public void getAllCustomerDetails() {
		getAllCustomerDetails.click();
	}
}
