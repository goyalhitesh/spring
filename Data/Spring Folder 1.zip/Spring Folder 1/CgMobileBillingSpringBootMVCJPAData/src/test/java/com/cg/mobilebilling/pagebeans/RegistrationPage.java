package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	@FindBy(name= "firstName")
	private WebElement firstName;
	
	@FindBy(name="lastName")
	private WebElement lastName;
	
	@FindBy(name="emailID")
	private WebElement emailID;
	
	@FindBy(name="dateOfBirth")
	private WebElement dateOfBirth;
	
	@FindBy(name="billingAddress.city")
	private WebElement city;
	
	@FindBy(name="billingAddress.state")
	private WebElement state;
	
	@FindBy(name="billingAddress.pinCode")
	private WebElement pinCode;
	
	@FindBy(how=How.XPATH, xpath="/html/body/div/table/tbody/tr[8]/td/input")
	private WebElement submit;
	
	@FindBy(name="HomePage")
	private WebElement homepage;
	
	@FindBy(how=How.ID,id="firstName.errors")
	private WebElement firstNameError;
	
	@FindBy(how=How.ID,id="lastName.errors")
	private WebElement lastNameError;
	
	@FindBy(how=How.ID,id="emailID.errors")
	private WebElement emailIdError;
	
	@FindBy(how=How.ID,id="dateOfBirth.errors")
	private WebElement dateOfBirthError;
	
	@FindBy(how=How.ID,id="billingAddress.city.errors")
	private WebElement cityError;
	
	@FindBy(how=How.ID,id="billingAddress.state.errors")
	private WebElement stateError;

	public RegistrationPage() {
		super();
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}

	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getPinCode() {
		return pinCode.getAttribute("value");
	}

	public void setPinCode(String pinCode) {
		this.pinCode.sendKeys(pinCode);
	}
	
	public String getFirstNameError() {
		return firstNameError.getText();
	}

	public String getLastNameError() {
		return lastNameError.getText();
	}

	public String getEmailIdError() {
		return emailIdError.getText();
	}

	public String getDateOfBirthError() {
		return dateOfBirthError.getText();
	}

	public String getCityError() {
		return cityError.getText();
	}

	public String getStateError() {
		return stateError.getText();
	}

	public void registerCustomer() {
		submit.click();
	}
	
	public void homePage() {
		homepage.click();
	}
}
