package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MonthlyBillDetailPage {
	@FindBy(name="customerID")
	private WebElement customerID;
	
	@FindBy(name="mobileNo")
	private WebElement mobileNo;
	
	@FindBy(name="billMonth")
	private WebElement billMonth;
	
	@FindBy(name="noOfLocalSMS")
	private WebElement noOfLocalSMS;
	
	@FindBy(name="noOfStdSMS")
	private WebElement noOfStdSMS;
	
	@FindBy(name="noOfLocalCalls")
	private WebElement noOfLocalCalls;
	
	@FindBy(name="noOfStdCalls")
	private WebElement noOfStdCalls;
	
	@FindBy(name="internetDataUsageUnits")
	private WebElement internetDataUsageUnits;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"bill\"]/table/tbody/tr[9]/td/input")
	private WebElement submit;
	
	@FindBy(name="HomePage")
	private WebElement homepage;

	public MonthlyBillDetailPage() {
		super();
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public String getBillMonth() {
		return billMonth.getAttribute("value");
	}

	public void setBillMonth(String billMonth) {
		this.billMonth.sendKeys(billMonth);
	}

	public String getNoOfLocalSMS() {
		return noOfLocalSMS.getAttribute("value");
	}

	public void setNoOfLocalSMS(String noOfLocalSMS) {
		this.noOfLocalSMS.sendKeys(noOfLocalSMS);
	}

	public String getNoOfStdSMS() {
		return noOfStdSMS.getAttribute("value");
	}

	public void setNoOfStdSMS(String noOfStdSMS) {
		this.noOfStdSMS.sendKeys(noOfStdSMS);
	}

	public String getNoOfLocalCalls() {
		return noOfLocalCalls.getAttribute("value");
	}

	public void setNoOfLocalCalls(String noOfLocalCalls) {
		this.noOfLocalCalls.sendKeys(noOfLocalCalls);
	}

	public String getNoOfStdCalls() {
		return noOfStdCalls.getAttribute("value");
	}

	public void setNoOfStdCalls(String noOfStdCalls) {
		this.noOfStdCalls.sendKeys(noOfStdCalls);
	}

	public String getInternetDataUsageUnits() {
		return internetDataUsageUnits.getAttribute("value");
	}

	public void setInternetDataUsageUnits(String internetDataUsageUnits) {
		this.internetDataUsageUnits.sendKeys(internetDataUsageUnits);
	}
	
	public void generateBill() {
		submit.click();
	}
	
	public void homePage() {
		homepage.click();
	}
}
