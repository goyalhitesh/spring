package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AllCustomerDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllCustomerDetailStepDefinition {
	
	private WebDriver driver;
	private AllCustomerDetailsPage allCustomerDetails;
	

	@Given("^User is on get all customer details Page$")
	public void user_is_on_get_all_customer_details_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:3333/getAllCustomerDetails");
		allCustomerDetails = PageFactory.initElements(driver, AllCustomerDetailsPage.class);
	}

	@When("^User clicks on Get all customer details button$")
	public void user_clicks_on_Get_all_customer_details_button() throws Throwable {
		allCustomerDetails.getAllCustomerDetails();
	}

	@Then("^Displays all the customer details in database$")
	public void displays_all_the_customer_details_in_database() throws Throwable {
	    String expectedEmail1 = "hitesh@gmail.com";
	    assertEquals(expectedEmail1, allCustomerDetails.getActualEmail1());
	    String expectedEmail2 = "vivek.b@gmail.com";
	    assertEquals(expectedEmail2, allCustomerDetails.getActualEmail2());
	    String expectedEmail3 = "diya@gmail.com";
	    assertEquals(expectedEmail3, allCustomerDetails.getActualEmail3());
	    String expectedEmail4 = "hitakshi@gmail.com";
	    assertEquals(expectedEmail4, allCustomerDetails.getActualEmail4());
	    String expectedEmail5 = "rahul@gmail.com";
	    assertEquals(expectedEmail5, allCustomerDetails.getActualEmail5());
	    //driver.close();
	}
	
	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
	    allCustomerDetails.homePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String expectedTitle1 = "WebApp1";
		assertEquals(expectedTitle1, driver.getTitle());
		//driver.close();
	}
}