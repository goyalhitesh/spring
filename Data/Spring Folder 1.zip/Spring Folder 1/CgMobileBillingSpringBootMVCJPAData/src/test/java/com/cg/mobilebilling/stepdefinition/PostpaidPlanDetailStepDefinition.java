package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PostpaidPlanDetailStepDefinition {

	@Given("^User is on getCustomerPostPaidAccountPlanDetailsPage Page$")
	public void user_is_on_getCustomerPostPaidAccountPlanDetailsPage_Page() throws Throwable {

	}

	@Then("^User is redirected to getCustomerPostPaidAccountPlanDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerPostPaidAccountPlanDetailsPage_page_and_details_gets_displayed() throws Throwable {

	}
}
