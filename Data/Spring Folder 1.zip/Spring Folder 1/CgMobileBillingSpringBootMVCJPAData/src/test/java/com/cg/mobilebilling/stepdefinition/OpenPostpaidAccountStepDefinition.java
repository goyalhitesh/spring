/*package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.PostpaidAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostpaidAccountStepDefinition {
	
	private WebDriver driver;
	private PostpaidAccountPage postpaidAccount;

	@Given("^User is on openPostpaidMobileAccountPage Page$")
	public void user_is_on_openPostpaidMobileAccountPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:3333/openPostpaidMobileAccount");
		postpaidAccount = PageFactory.initElements(driver, PostpaidAccountPage.class);
	}
	
	@When("^User enter his ID and plan ID correctly$")
	public void user_enter_his_ID_and_plan_ID_correctly() throws Throwable {
		postpaidAccount.setCustomerID("20023");
		postpaidAccount.setPlanID("1002");
		postpaidAccount.openAccount();
	}

	@Then("^User is redirected to openPostpaidMobileAccountPage page and message gets displayed$")
	public void user_is_redirected_to_openPostpaidMobileAccountPage_page_and_message_gets_displayed() throws Throwable {
		String expectedTitle = "Open Postpaid Account";
		assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}
	
	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
		postpaidAccount.homePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String expectedTitle1 = "WebApp1";
		assertEquals(expectedTitle1, driver.getTitle());
//		driver.close();
	}
}
*/