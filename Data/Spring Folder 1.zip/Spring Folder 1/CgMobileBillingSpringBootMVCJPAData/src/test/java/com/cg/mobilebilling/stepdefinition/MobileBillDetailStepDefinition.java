package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.When;

public class MobileBillDetailStepDefinition {

	@When("^User enter his correct credentials and click on bill details button$")
	public void user_enter_his_correct_credentials_and_click_on_bill_details_button() throws Throwable {

	}
}
