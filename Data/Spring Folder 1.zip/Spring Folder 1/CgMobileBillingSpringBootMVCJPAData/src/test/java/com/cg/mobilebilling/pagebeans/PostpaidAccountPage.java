package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PostpaidAccountPage {
	@FindBy(name="customerID")
	private WebElement customerID;
	
	@FindBy(name="planID")
	private WebElement planID;
	
	@FindBy(name="submit")
	private WebElement submit;
	
	@FindBy(name="HomePage")
	private WebElement homepage;

	public PostpaidAccountPage() {
		super();
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public String getPlanID() {
		return planID.getAttribute("value");
	}

	public void setPlanID(String planID) {
		this.planID.sendKeys(planID);
	}
	
	public void openAccount() {
		submit.click();
	}
	
	public void homePage() {
		homepage.click();
	}
}
