package com.cg.mobilebilling.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;

@Controller
public class URIController {

	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}

	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/index")
	public String getHomePage() {
		return "indexPage";
	}
	
	@RequestMapping("/openPostpaidMobileAccount")
	public String openPostpaidMobileAccountPage() {
		return "openPostpaidMobileAccountPage";
	}

	@RequestMapping("/getCustomerDetails")
	public String getCustomerDetailsPage() {
		return "getCustomerDetailsPage";
	}
	
	@RequestMapping("/getAllCustomerDetails")
	public String getAllCustomerDetailsPage() {
		return "getAllCustomerDetailsPage";
	}
	
	@RequestMapping("/getPostPaidAccountDetails")
	public String getPostPaidAccountDetailsPage() {
		return "getPostPaidAccountDetailsPage";
	}
	
	@RequestMapping("/deleteCustomer")
	public String deleteCustomerPage() {
		return "deleteCustomerPage";
	}
	
	@RequestMapping("/closeCustomerPostPaidAccount")
	public String closeCustomerPostPaidAccountPage() {
		return "closeCustomerPostPaidAccountPage";
	}
	
	@RequestMapping("/getCustomerPostPaidAccountPlanDetails")
	public String getCustomerPostPaidAccountPlanDetailsPage() {
		return "getCustomerPostPaidAccountPlanDetailsPage";
	}
	
	@RequestMapping("/changePlan")
	public String changePlanPage() {
		return "changePlanPage";
	}
	
	@RequestMapping("/getMobileBillDetails")
	public String getMobileBillDetailsPage() {
		return "getMobileBillDetailsPage";
	}
	
	@RequestMapping("/getCustomerPostPaidAccountAllBillDetails")
	public String getCustomerPostPaidAccountAllBillDetailsPage() {
		return "getCustomerPostPaidAccountAllBillDetailsPage";
	}
	
	@RequestMapping("/getCustomerAllPostpaidAccountsDetails")
	public String getCustomerAllPostpaidAccountsDetailsPage() {
		return "getCustomerAllPostpaidAccountsDetailsPage";
	}
	
	@RequestMapping("/generateMonthlyMobileBill")
	public String generateMonthlyMobileBillPage() {
		return "generateMonthlyMobileBillPage";
	}
	
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	
	@ModelAttribute
	public PostpaidAccount getAccount() {
		return new PostpaidAccount();
	}
	
	@ModelAttribute
	public Plan getPlan() {
		return new Plan();
	}
}
