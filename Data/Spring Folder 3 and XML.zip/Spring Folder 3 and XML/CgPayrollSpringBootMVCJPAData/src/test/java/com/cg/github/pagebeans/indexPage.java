package com.cg.github.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class indexPage {
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[3]/td/a")
	private WebElement link;
	
	public indexPage() {	}

	public void clickRegistration() {
		link.click();
	}
}