package com.cg.payroll.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;

@Controller
public class URIController {
	
	Associate asscoiate;
	
	@RequestMapping("/")		
	public String getIndexOf() {
		return "IndexPage";
	}
	
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registration";
	}
	
	@ModelAttribute
	public Associate getAssociate() {
		asscoiate = new Associate();
		return asscoiate;
	}
}
