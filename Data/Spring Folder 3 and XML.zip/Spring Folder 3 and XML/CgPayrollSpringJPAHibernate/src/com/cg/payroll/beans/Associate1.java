package com.cg.payroll.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


public class Associate1 {
/*	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int associateId;
	private String firstName, lastName, designation, emailId;
	public Associate1() {
		super();
	}
	public Associate1(int associateId, String firstName, String lastName,
			String designation, String emailId) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.emailId = emailId;
		
		
	}
	public Associate1(String firstName, String lastName, String designation,
			String emailId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.emailId = emailId;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", designation="
				+ designation + ", emailId=" + emailId + "]";
	}
}*/
}
