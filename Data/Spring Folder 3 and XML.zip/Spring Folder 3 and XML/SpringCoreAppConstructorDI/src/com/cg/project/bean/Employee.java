package com.cg.project.bean;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int employeeId, salary;
	private String firstName, lastName;
	
	@Autowired
	private Address address;
	
/*	public Employee(int employeeId, int salary, String firstName, String lastName, Address address) {
		super();
		this.employeeId = employeeId;
		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}*/
	
	public Employee() {
}
	public Employee(int employeeId, int salary, String firstName,
			String lastName) {
		super();
		this.employeeId = employeeId;
		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", salary=" + salary
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + "]";
	}
}
